import requests

web = requests.session()
